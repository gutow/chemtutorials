Clazz.declarePackage("JSV.api");
Clazz.declareInterface(JSV.api, "JSVMainPanel", JSV.api.JSVViewPanel);
;//5.0.1-v7 Wed Jun 03 09:22:38 CDT 2026
