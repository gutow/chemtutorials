Clazz.declarePackage("JS");
Clazz.declareInterface(JS, "SwingController");
;//5.0.1-v7 Wed Jun 03 09:22:38 CDT 2026
